// NPM MODULE 

var validator = require('validator');

//console.log(validator.isEmail('ariyan@gmail.com1'));

// console.log(validator.isJSON(JSON.stringify({name:'ariyan'})));
console.log(validator.isPort('300443343430'));