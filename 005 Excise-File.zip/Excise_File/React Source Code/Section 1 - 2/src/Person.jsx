import React, { Component } from 'react'

export class Person extends Component {

     
     
     render() {
          return (
               <div className="App">
               <h1>Class name:  Base Componente for test   </h1>
              </div>
          )
     }
}

export default Person
