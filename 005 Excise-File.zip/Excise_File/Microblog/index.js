//  sessionStorage.setItem('name','Kazi');
//  localStorage.setItem('name','Ariyan');